# Housings_LGA.pretty

This repository contains various Land-Grid-Array packages - https://github.com/KiCad/Housings_LGA.pretty
