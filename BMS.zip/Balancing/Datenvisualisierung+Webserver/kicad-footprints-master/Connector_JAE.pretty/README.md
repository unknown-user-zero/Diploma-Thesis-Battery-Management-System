# Connector_JAE.pretty
This library contains footprints for JAE connectors

---

Footprints for the following connectors are generated with the folowing script:

- LY20

Script details:

- author: Poeschl Rene
- script location: https://github.com/pointhi/kicad-footprint-generator/tree/master/scripts/Connector/Connector_JAE/
- used config file: config_KLCv3.0.yaml
- python version: 3.6.2
