# Connector_Samtec.pretty
This library contains footprints for Samtec connectors

---

Specialized scripts are used to generate the following connectors:

- LHMS

Script details:

- author: Poeschl Rene
- script location: https://github.com/pointhi/kicad-footprint-generator/tree/master/scripts/Connector/Connector_Samtec/
- used config file: config_KLCv3.0.yaml
- python version: 3.6.2
