# Conn_PinSocket_1.00mm.pretty

These footprints have been script-generated with a python script available at https://github.com/pointhi/kicad-footprint-generator/scripts/Conn_PinSocket
